Please do below things to run project successfully

1) Create new database and execute TablesScript.sql

2) Change SQL ConnectionString in appsettings.json

3) Done - Now project will automatically seed sample data

4) Use below credentials to authorize Web API
   username: test@email.com
   Password: Test@@123

5) I have used SwaggerUI so we can test Web API in Browser

6) Also Included Postman Collection